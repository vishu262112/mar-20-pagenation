package model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "CUSTOMER")
public class Customer {

	@Id
	@Column(name ="CUSTID")
	private String customerId;
	@Column(name ="FNAME")
	private String firstName;
	@Column(name ="MNAME")
	private String middleName;
	@Column(name ="LTNAME")
	private String lastName;
	@Column(name ="CITY")
	private String city;
	@Column(name ="MOBILENO")
	private String mobileNumber;
	@Column(name ="OCCUPATION")
	private String occupation;
	@Column(name ="DOB")
	private Date dateOfBirth;
	@Transient
	SimpleDateFormat sdf;
	
	public Customer() {
	
		sdf = new SimpleDateFormat("dd-MMM-yyyy");
	}

	public Customer(String customerId, String firstName, String middleName, String lastName, String city,
			String mobileNumber, String occupation, Date dateOfBirth) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.city = city;
		this.mobileNumber = mobileNumber;
		this.occupation = occupation;
		this.dateOfBirth = dateOfBirth;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Date getdateOfBirth() {
		return dateOfBirth;
	}
	
	public String getdateOfBirth1() {
		return sdf.format(dateOfBirth);
	}

	public void setdateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", city=" + city + ", mobileNumber=" + mobileNumber + ", occupation="
				+ occupation + ", dateOfBirth=" + getdateOfBirth1() + "]";
	}
	
	
}
