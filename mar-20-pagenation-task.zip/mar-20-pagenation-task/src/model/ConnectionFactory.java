package model;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ConnectionFactory {
	public static Session getConnection() 
	{
		Configuration config=new Configuration();
		config.configure("hibernate.cfg.xml");
		config.addAnnotatedClass(model.Customer.class);

		SessionFactory sf = config.buildSessionFactory();
		Session session = sf.openSession();
		return session;
	}
}

