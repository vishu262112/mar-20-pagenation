package model;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import model.ConnectionFactory;

public class CustomerDao {

	public Serializable create(Customer customer) {
		Session session = ConnectionFactory.getConnection();
        Transaction tran = session.beginTransaction();
        Serializable customerId = session.save(customer);
//        System.out.println("Movie is added to the db. Note down its id: "+Cusid);
        tran.commit();
        session.close();
        return customerId;
		}
	
	public Customer read(String customerId) {
		Session session = ConnectionFactory.getConnection();
        
        return (Customer) session.get(Customer.class, customerId);
        
	}
	
	
	public List<Customer> read(){
		Session session = ConnectionFactory.getConnection();
		
		Criteria criteria=session.createCriteria(Customer.class);
		return criteria.list();
		
	}
	
	public void update(Customer arg)
	{
		Session session = ConnectionFactory.getConnection();
		Customer customer = (Customer) session.get(Customer.class, arg.getCustomerId());
		customer.setFirstName(arg.getFirstName());
		customer.setMiddleName(arg.getMiddleName());
		customer.setLastName(arg.getLastName());
		customer.setCity(arg.getCity());
		customer.setMobileNumber(arg.getMobileNumber());
		customer.setOccupation(arg.getOccupation());
		customer.setdateOfBirth(arg.getdateOfBirth());
		
        Transaction tran = session.beginTransaction();
        session.persist(customer);
        tran.commit();
        session.close();

	}
	
	public void delete(String customerId)
	{
		
		Session session = ConnectionFactory.getConnection();
		Customer customer = (Customer) session.get(Customer.class,customerId);

        Transaction tran = session.beginTransaction();
        session.delete(customer);
        tran.commit();
        session.close();

		
	}
	
	
}
